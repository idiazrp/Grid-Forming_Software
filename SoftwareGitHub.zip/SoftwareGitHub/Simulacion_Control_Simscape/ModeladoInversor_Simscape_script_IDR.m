%% Inicialización
%clear
%%--PARÁMETROS FILTRO---
L_r = 300 * 10^-6; 
C_r = 8.5*10^-6;
R_L_r = 1; 
R_C_r = 100000;
R_Load_r = 20;
L_Load_r = 10e-3;
%%--------------------  
%%-----BASES------
Ib = 2;
Vb = 0.61*48/sqrt(3);
Zb = Vb/Ib;
fb = 50;
wb = fb * 2 * pi;
Cb = 1/wb/Zb;
Lb = Zb/wb;
%%----------------

%%------PU------
R_C = R_C_r/Zb;
R_L = R_L_r/Zb;
R_Load = R_Load_r/Zb;
C = C_r/Cb;
L = L_r/Lb;
%%--------------

w_r = 50*2*pi;
w = w_r/wb;

Vref = Vb;
Vs = 48;
f_pulso = 601*50;


%% Copiar y pegar salida de consola de diseno_ControlTensiones_script_IDR aquí:

%------LAZO INTERNO:----------
%Tipo control elegido: 2. Por diseño analítico (da)
%wn_L = 3000.000000;
%seta_L = 0.730000;
Kp_L = 0.037149;
Idef_L = 319.435600;
b_L = 1.000000;

%------LAZO EXTERNO:----------
%Tipo control elegido: 2. Por wo y retraso del control integral (rc)
%w_rc_C = 1800.000000;
%fasePI_C = -10.000000;
Kp_C = 0.136513;
Idef_C = 43.327708;
b_C = 1.000000;