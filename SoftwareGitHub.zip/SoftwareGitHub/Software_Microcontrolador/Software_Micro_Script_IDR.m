%% Laplace
clear
s=tf('s');

%% PWM
Freq_Clock = 200e6;
TimerPeriod = 1024; %Para conseguir un valor de Freq Conmutacion parecido a 50kHz.
%Esto permite una frecuencia de muestreo de 15kHz aprox que evita problemas
%al ser unas 5 veces mayor que la de resonancia del filtro (aprox 2,8kHz)
Freq_Conmutacion = Freq_Clock/(TimerPeriod*4);
T_pwm = 2e-5;
Ts = 3*T_pwm;

TimerPeriod_Output = 5000; %Los PWM de las salidas tienen un timerPeriod distinto a las entradas
%TimerPeriod = 5000; %Valores originales en programa de Jorge
%Freq_Conmutacion = 15e3;
%% PARÁMETROS EN REALES
Vdc = 48; %Tensión de continua del inversor
w_r = 50*2*pi; %Frecuencia en reales
m = 0.5;

%----INDUCTANCIA INVERSOR (solo para controles P y PI de intensidad)-----
R_serie = 0;  
X_ind = 5.881e-3; 
R_ind = 1.1+R_serie; 
Z_ind = sqrt(X_ind^2 + R_ind^2); 

%--PARÁMETROS FILTRO---
L_r = 300 * 10^-6; 
C_r = 8.5*10^-6;
R_L_r = 1; 
R_C_r = 100000;
R_Load_r = 16.9;

%% BASES Y PASO A PU
%-----BASES------
Ib = 2;
Vb = 0.61*48/sqrt(3);
Zb = Vb/Ib;
fb = 50;
wb = fb * 2 * pi;
Cb = 1/wb/Zb;
Lb = Zb/wb;
Sb= 3 * Vb * Ib;                          
                       
%------PASO A PU------
Lpu=X_ind/ Lb;              %Inductancia inversor
Rpu=R_ind / Zb;                          

R_C = R_C_r/Zb;             %Parámetros filtro
R_L = R_L_r/Zb;
R_Load = R_Load_r/Zb;
C = C_r/Cb;
L = L_r/Lb;

w = w_r/wb;                 %w en pu

%% Controles P y PI con solo carga
%Simulink los sobreescribe con los del popup pero mejor tenerlos fijos
%Control P solo intensidades
K_proporcional = 6.2255;
b_proporcional = 1;
%Control PI solo intensidades
K_integral = 0.2582*0.1;
I_integral = 0.0013;
b_integral = 1;

%% Control PI con filtro, copiar y pegar resultado de diseno_ControlTensiones_script_IDR

%------LAZO INTERNO:----------
%Tipo control elegido: 2. Por diseño analítico (da)
%wn_L = 3000.000000;
%seta_L = 0.730000;
Kp_L = 0.037149;
Idef_L = 319.435600;
b_L = 1.000000;

%------LAZO EXTERNO:----------
%Tipo control elegido: 2. Por wo y retraso del control integral (rc)
%w_rc_C = 1800.000000;
%fasePI_C = -10.000000;
Kp_C = 0.136513;
Idef_C = 43.327708;
b_C = 1.000000;
%% GANANCIAS
%---ADC Tensiones en carga ADC------
g_divisor = 1/23; %Divisor tensión de la entrada de la realimentación
g_ampli_galvanico = 2; %Ganancia media del amplificador AMC3330Q1
%G1 = 3.3/2^12/g_divisor/g_ampli_galvanico/Vb;
%G1a = G1 * 0.966678; %Correcciones por asimetrías en los ADCs (valores experimentales)
%G1b = G1 * 0.997188;
%G1c = G1 * 0.996309;
G1a = 3.3/2^12;
G1b = 1/g_divisor/g_ampli_galvanico/Vb;
%----ADC Intensidades ADC------
Rs = 0.015; %Resistencia Shunt de fase
g_INA240 = 20; %Ganancia del amplificador de la lectura de intensidades
G2 = 3.3/2^12/Rs/g_INA240/Ib;

%----Referencias V-------
G3 = 1/Vb; %Paso a pu

%----Control/Desacoplamiento Controles P y PI solo I----
G4 = Lpu*w;

%----Control: control PI intensidad y tensión----
G5 = w*C; %Desacoplamiento control tensiones
G6 = w*L; %Desacoplamiento control intensidades

%-----PWMs de salida----
G7 = round(2*5000*sqrt(2)/sqrt(3)/5); 
G8 = round(5000*sqrt(2)/sqrt(3));
G9 = 5000; %Ganancia por defecto para el ángulo


