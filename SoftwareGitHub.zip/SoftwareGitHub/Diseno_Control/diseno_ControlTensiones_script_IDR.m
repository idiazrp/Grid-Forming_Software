%% Inicialización
clc
clear
s=tf('s');

%%----FILTRO LC-----
%El sufijo _r indica que la medida tiene unidades reales. Su ausencia
%excepto en el caso de las bases indica pu.
L_r = 300 * 10^-6; %Inductancia filtro
C_r = 8.5*10^-6; %Condensador filtro
R_L_r = 1; %Resistencia inductancia filtro
R_C_r = 100000; %Resistencia condensador filtro
R_Load_r = 20; %Resistencia de la carga
L_Load_r = 10e-3; %Inductancia de la carga
%------------------

%%-----BASES------
Ib = 2;
Vb = 0.61*48/sqrt(3);
fb = 50;
wb = fb * 2 * pi;
Sb = 3*Vb*Ib;
Zb = Vb/Ib;
Cb = 1/wb/Zb;
Lb = Zb/wb;
%%----------------

%---Cambio a pu---
R_C = R_C_r/Zb;
R_L = R_L_r/Zb;
R_Load = R_Load_r/Zb;
C = C_r/Cb;
L = L_r/Lb;
L_Load = L_Load_r/Lb;

%-----------------

w_r = 50*2*pi;
w = w_r/wb;

Vref = Vb;

%%----PLACEHOLDERS----------Para que linearize
% no dé fallos por falta de parámetros. No cambiar
b_L = 1;
Idef_L = 1;
Kp_L = 1;
b_C = 1;
Idef_C = 1;
Kp_C = 1;
%%---------------------------

%% Parámetros de los controles (MODIFICAR AQUÍ)
%%--------ESPECIFICACIONES DEL CONTROL DEL LAZO INTERNO-------
%1. Por wo y margen de fase (mf)
Fm_L = 165; %Margen de fase del lazo interno. Subirlo a 143 grados. A más de 90 para que funcione por ser de primer orden
wo_L = 3000/wb; %Pulsación de cruce (entre esto y 3000)

%2. Por diseño analítico (da)
wn_L = 3000; %No hace falta dividir por wb
seta_L = 0.73;

%%3. Por wo y retraso del control integral (rc)
w_rc_L = 1700;
fasePI_L = -10;

%SELECCIONAR TIPO DISEÑO ELEGIDO:
tipo_control_L = 2;

%SELECCIONAR VALOR DE LA PONDERACIÓN DE LA REFERENCIA
b_L = 1;
%Recomendable poner a 1 en los casos 1 y 3.
%--------------------------------------------------------------


%%--------ESPECIFICACIONES DEL CONTROL DEL LAZO EXTERNO-------
%1. Por wo y margen de fase (mf)
Fm_C = 60; %Margen de fase del lazo interno. Subirlo a 143 grados. A más de 90 para que funcione por ser de primer orden
wo_C = 2000; %Pulsación de cruce (entre esto y 3000)

%%2. Por wo y retraso del control integral (rc)
w_rc_C = 1800;
fasePI_C=-10;

%%3. Por margen de ganancia
Am_C = 0.05;
wu_C = 3500;

%SELECCIONAR TIPO DISEÑO ELEGIDO:
tipo_control_C = 2;

%SELECCIONAR VALOR DE LA PONDERACIÓN DE LA REFERENCIA
b_C = 1;
%Recomendable poner a 1 en los casos 1 y 3.
%------------------------------------------


%% Lazo interno (solo L)
%%Como las plantas salen iguales en d y en q solo hace falta diseñar un control

%%----Linearización de planta P_L (inductancias)-------
mdl = 'diseno_ControlTensiones_simulink_IDR';     
open_system(mdl)
io(1)=linio('diseno_ControlTensiones_simulink_IDR/PI_L_d',1,'input');
io(2)=linio('diseno_ControlTensiones_simulink_IDR/PI_L_q',1,'input');
io(3)=linio('diseno_ControlTensiones_simulink_IDR/Inductancias',1,'openoutput');
io(4)=linio('diseno_ControlTensiones_simulink_IDR/Inductancias',2,'openoutput');
P_lin_L = linearize(mdl,io);
P_lin_L_tf = tf(P_lin_L); %Obtiene la matriz de funciones de transferencia entre los ejes d y q
P_L = P_lin_L_tf(1,1); %Como d-d y q-q son iguales solo interesa coger uno (d-d).
%%----------------------------------


%%--------CÁLCULO PARÁMETROS CONTROL-------
%%1. Por margen de fase y wo
Fc_L=-180+Fm_L-180/pi*angle(freqresp(P_L,wo_L)); %Fase del control
Ap_L=abs(freqresp(P_L,wo_L));
Ac_L=1/Ap_L; %Ganancia del control
I_L_mf=tand(90+Fc_L)/wo_L; %Parámetros del control
Kp_L_mf=Ac_L*I_L_mf*wo_L/sqrt(1+(I_L_mf*wo_L)^2); 
Idef_L_mf=Kp_L_mf/I_L_mf; %I que se mete en el bloque específico de Simulink

%%2. Por diseño analítico (más detallado en disenoAnalitico.m)
syms K I ver
eqs = [sqrt(K*wb/I/L)==wn_L,2*seta_L*wn_L==(wb/L)*(R_L+K)];
ver = vpasolve(eqs,[I K]);
I_L_da=double(ver.I);
Kp_L_da=double(ver.K);
Idef_L_da=Kp_L_da/I_L_da;

%%3. Por wo y retraso del control integral
I_L_rc=tand(90+fasePI_L)/w_rc_L;
Kp_L_rc=1/abs(freqresp((1+I_L_rc*s)/I_L_rc/s,w_rc_L))/abs(freqresp(P_L,w_rc_L));
Idef_L_rc=Kp_L_rc/I_L_rc;

%------------------------------------------


%%. Funciones del control y lazo abierto y cerrado según diseño elegido
if tipo_control_L == 1
I_L = I_L_mf;
Kp_L = Kp_L_mf;
Idef_L = Idef_L_mf;
end 

if tipo_control_L == 2
I_L = I_L_da;
Kp_L = Kp_L_da;
Idef_L = Idef_L_da;
end

if tipo_control_L == 3
I_L = I_L_rc;
Kp_L = Kp_L_rc;
Idef_L = Idef_L_rc;
end

C_L_1=minreal(b_L*Kp_L+Kp_L/I_L/s); %Control referencia -> mando
C_L_2=minreal(Kp_L+Kp_L/I_L/s); %Control salida -> mando

G_L = minreal(C_L_1*P_L); %Lazo interno abierto
F_L = minreal(C_L_1*P_L/(1+P_L*C_L_2)); %Lazo interno cerrado


%% Lazo externo (L+C)

%%Linearización de planta-------
mdl = 'diseno_ControlTensiones_simulink_IDR';
open_system(mdl);
io(1)=linio('diseno_ControlTensiones_simulink_IDR/PI_C_d',1,'input');
io(2)=linio('diseno_ControlTensiones_simulink_IDR/PI_C_q',1,'input');
io(3)=linio('diseno_ControlTensiones_simulink_IDR/Condensadores',1,'openoutput');
io(4)=linio('diseno_ControlTensiones_simulink_IDR/Condensadores',2,'openoutput');
P_lin = linearize(mdl,io);
P_lin_tf = tf(P_lin);
P_C = P_lin_tf(1,1);
%---------------------


%%--------CÁLCULO PARÁMETROS CONTROL-------
%%1. Por margen de fase y wo (mf)
Fc_C=-180+Fm_C-180/pi*angle(freqresp(P_C,wo_C)); %Fase del control
Ap_C=abs(freqresp(P_C,wo_C));
Ac_C=1/Ap_C; %Ganancia del control
I_C_mf=tand(90+Fc_C)/wo_C; %Parámetros del control
Kp_C_mf=Ac_C*I_C_mf*wo_C/sqrt(1+(I_C_mf*wo_C)^2); 
Idef_C_mf=Kp_C_mf/I_C_mf; %I que se mete en el bloque específico de Simulink

%%2. Por wo y retraso del control integral (rc)
I_C_rc=tand(90+fasePI_C)/w_rc_C;
Kp_C_rc=1/abs(freqresp((1+I_C_rc*s)/I_C_rc/s,w_rc_C))/abs(freqresp(P_C,w_rc_C));
Idef_C_rc=Kp_C_rc/I_C_rc;

%%3. Por margen de ganancia y wu (mg)
Fc_C=-180-180/pi*angle(freqresp(P_C,wu_C)); %Fase del control
Ap_C=abs(freqresp(P_C,wu_C));
Ac_C=1/Am_C/Ap_C; %Ganancia del control
I_C_mg=tand(90+Fc_C)/wu_C; %Parámetros del control
Kp_C_mg=Ac_C*I_C_mg*wo_C/sqrt(1+(I_C_mg*wu_C)^2); 
Idef_C_mg=Kp_C_mg/I_C_mg; %I que se mete en el bloque específico de Simulink
%-----------------------------------------

%%. Funciones del control y lazo abierto y cerrado según diseño elegido
if tipo_control_C == 1
I_C = I_C_mf;
Kp_C = Kp_C_mf;
Idef_C = Idef_C_mf;
end 

if tipo_control_C == 2
I_C = I_C_rc;
Kp_C = Kp_C_rc;
Idef_C = Idef_C_rc;
end

if tipo_control_C == 3
I_C = I_C_mg;
Kp_C = Kp_C_mg;
Idef_C = Idef_C_mg;
end 

C_C_1=minreal(b_C*Kp_C+Kp_C/I_C/s); %Control referencia -> mando
C_C_2=minreal(Kp_C+Kp_C/I_C/s); %Control salida -> mando

G_C = minreal(C_C_1*P_C); %Lazo interno abierto
F_C = minreal(C_C_1*P_C/(1+P_C*C_C_2)); %Lazo interno cerrado


%% Sacar por consola para copiar
fprintf('\n\n%%------LAZO INTERNO:----------');
fprintf('\n%%Tipo control elegido: ')
if tipo_control_L == 1
fprintf('1. Por wo y margen de fase (mf)');
fprintf('\n%%wo_L = %f;',wo_L);
fprintf('\n%%Fm_L = %f;',Fm_L);
end
if tipo_control_L == 2
fprintf('2. Por diseño analítico (da)');
fprintf('\n%%wn_L = %f;',wn_L);
fprintf('\n%%seta_L = %f;',seta_L);
end
if tipo_control_L == 3
fprintf('3. Por wo y retraso del control integral (rc)');
fprintf('\n%%w_rc_L = %f;',w_rc_L);
fprintf('\n%%fasePI_L = %f;',fasePI_L);
end
fprintf('\nKp_L = %f;',Kp_L);
fprintf('\nIdef_L = %f;',Idef_L);
fprintf('\nb_L = %f;',b_L);


fprintf('\n\n%%------LAZO EXTERNO:----------');
fprintf('\n%%Tipo control elegido: ')
if tipo_control_C == 1
fprintf('1. Por wo y margen de fase (mf)');
fprintf('\n%%wo_C = %f;',wo_C);
fprintf('\n%%Fm_C = %f;',Fm_C);
end
if tipo_control_C == 2
fprintf('2. Por wo y retraso del control integral (rc)');
fprintf('\n%%w_rc_C = %f;',w_rc_C);
fprintf('\n%%fasePI_C = %f;',fasePI_C);
end
if tipo_control_C == 3
fprintf('3. Por margen de ganancia y wu (mg)');
fprintf('\n%%wu_C = %f;',wu_C);
fprintf('\n%%Am_C = %f;',Am_C);
end
fprintf('\nKp_C = %f;',Kp_C);
fprintf('\nIdef_C = %f;',Idef_C);
fprintf('\nb_C = %f;\n',b_C);
